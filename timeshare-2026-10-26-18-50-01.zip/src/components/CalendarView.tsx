import React, { useState, useRef, useEffect } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  CheckSquare,
  MessageCircle,
  FileSpreadsheet,
  ArrowLeft,
  Repeat,
} from 'lucide-react';
import { CalendarEvent, Member, SharedCalendar } from '../types';

interface CalendarViewProps {
  events: CalendarEvent[];
  calendars: SharedCalendar[];
  activeCalendarId: string;
  members: Member[];
  onSelectEvent: (event: CalendarEvent) => void;
  onCreateEventAtDate: (dateStr: string) => void;
  onDeleteEvent: (id: string, recurringGroupId?: string) => void;
  onOpenRosterScanner?: () => void;
  focusDateTrigger?: string | null;
}

// Helper to enumerate all YYYY-MM-DD dates between startDate and endDate inclusive (capped at 60 days safety)
function getDatesInRange(startDateStr: string, endDateStr?: string): string[] {
  if (!endDateStr || endDateStr <= startDateStr) {
    return [startDateStr];
  }
  const [sy, sm, sd] = startDateStr.split('-').map(Number);
  const [ey, em, ed] = endDateStr.split('-').map(Number);
  if (!sy || !sm || !sd || !ey || !em || !ed) return [startDateStr];

  const dates: string[] = [];
  const curr = new Date(sy, sm - 1, sd);
  const end = new Date(ey, em - 1, ed);
  let steps = 0;

  while (curr <= end && steps < 60) {
    const y = curr.getFullYear();
    const m = String(curr.getMonth() + 1).padStart(2, '0');
    const d = String(curr.getDate()).padStart(2, '0');
    dates.push(`${y}-${m}-${d}`);
    curr.setDate(curr.getDate() + 1);
    steps++;
  }
  return dates;
}

function formatShortMonthDay(dateStr: string): string {
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  return `${Number(parts[1])}/${Number(parts[2])}`;
}

function shiftDateString(dateStr: string, deltaDays: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  if (!y || !m || !d) return dateStr;
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + deltaDays);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(
    dt.getDate()
  ).padStart(2, '0')}`;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  events,
  activeCalendarId,
  members,
  onSelectEvent,
  onCreateEventAtDate,
  onOpenRosterScanner,
  focusDateTrigger,
}) => {
  const todayStr = new Date().toISOString().substring(0, 10);

  // Calendar state
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'month' | 'agenda'>('month');
  const [selectedDayDate, setSelectedDayDate] = useState<string>(todayStr);
  const [isDayScheduleOpen, setIsDayScheduleOpen] = useState<boolean>(false);

  // Jump to imported shifts' month when focusDateTrigger changes
  useEffect(() => {
    if (!focusDateTrigger) return;
    const cleanDateStr = focusDateTrigger.split('#')[0];
    const [y, m] = cleanDateStr.split('-').map(Number);
    if (y && m >= 1 && m <= 12) {
      setCurrentDate(new Date(y, m - 1, 1));
      setSelectedDayDate(cleanDateStr);
    }
  }, [focusDateTrigger]);

  // Slide / Swipe animation feedback state
  const [monthSlideDir, setMonthSlideDir] = useState<'left' | 'right' | null>(null);
  const [daySlideDir, setDaySlideDir] = useState<'left' | 'right' | null>(null);

  // Touch & Pointer refs for Month Grid swipe (Prev/Next Month)
  const monthSwipeStartRef = useRef<{ x: number; y: number } | null>(null);
  const monthDidSwipeRef = useRef<boolean>(false);

  // Touch & Pointer refs for Day Schedule swipe (Prev/Next Day)
  const daySwipeStartRef = useRef<{ x: number; y: number } | null>(null);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth(); // 0-indexed

  // Month Navigation handlers with slide visual feedback
  const handlePrevMonth = () => {
    setMonthSlideDir('right');
    setCurrentDate(new Date(year, month - 1, 1));
    setTimeout(() => setMonthSlideDir(null), 220);
  };

  const handleNextMonth = () => {
    setMonthSlideDir('left');
    setCurrentDate(new Date(year, month + 1, 1));
    setTimeout(() => setMonthSlideDir(null), 220);
  };

  const handleToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDayDate(today.toISOString().substring(0, 10));
  };

  // Day Navigation handlers (Prev / Next Day) with slide visual feedback
  const handleGoPrevDay = () => {
    setDaySlideDir('right');
    const prev = shiftDateString(selectedDayDate, -1);
    setSelectedDayDate(prev);
    const [py, pm] = prev.split('-').map(Number);
    if (py && pm && (py !== year || pm - 1 !== month)) {
      setCurrentDate(new Date(py, pm - 1, 1));
    }
    setTimeout(() => setDaySlideDir(null), 200);
  };

  const handleGoNextDay = () => {
    setDaySlideDir('left');
    const next = shiftDateString(selectedDayDate, 1);
    setSelectedDayDate(next);
    const [ny, nm] = next.split('-').map(Number);
    if (ny && nm && (ny !== year || nm - 1 !== month)) {
      setCurrentDate(new Date(ny, nm - 1, 1));
    }
    setTimeout(() => setDaySlideDir(null), 200);
  };

  // Month Grid Swipe Handlers (Touch & Mouse Drag)
  const onMonthTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length !== 1) return;
    monthDidSwipeRef.current = false;
    monthSwipeStartRef.current = {
      x: e.touches[0].clientX,
      y: e.touches[0].clientY,
    };
  };

  const onMonthTouchEnd = (e: React.TouchEvent) => {
    if (!monthSwipeStartRef.current || e.changedTouches.length === 0) return;
    const dx = e.changedTouches[0].clientX - monthSwipeStartRef.current.x;
    const dy = e.changedTouches[0].clientY - monthSwipeStartRef.current.y;
    monthSwipeStartRef.current = null;

    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.2) {
      monthDidSwipeRef.current = true;
      if (dx > 0) {
        handlePrevMonth();
      } else {
        handleNextMonth();
      }
    }
  };

  const onMonthMouseDown = (e: React.MouseEvent) => {
    monthDidSwipeRef.current = false;
    monthSwipeStartRef.current = { x: e.clientX, y: e.clientY };
  };

  const onMonthMouseUp = (e: React.MouseEvent) => {
    if (!monthSwipeStartRef.current) return;
    const dx = e.clientX - monthSwipeStartRef.current.x;
    const dy = e.clientY - monthSwipeStartRef.current.y;
    monthSwipeStartRef.current = null;

    if (Math.abs(dx) > 65 && Math.abs(dx) > Math.abs(dy) * 1.3) {
      monthDidSwipeRef.current = true;
      if (dx > 0) {
        handlePrevMonth();
      } else {
        handleNextMonth();
      }
    }
  };

  // Day Schedule Panel Swipe Handlers (Touch & Mouse Drag)
  const onDayTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length !== 1) return;
    daySwipeStartRef.current = {
      x: e.touches[0].clientX,
      y: e.touches[0].clientY,
    };
  };

  const onDayTouchEnd = (e: React.TouchEvent) => {
    if (!daySwipeStartRef.current || e.changedTouches.length === 0) return;
    const dx = e.changedTouches[0].clientX - daySwipeStartRef.current.x;
    const dy = e.changedTouches[0].clientY - daySwipeStartRef.current.y;
    daySwipeStartRef.current = null;

    if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.2) {
      if (dx > 0) {
        handleGoPrevDay();
      } else {
        handleGoNextDay();
      }
    }
  };

  const onDayMouseDown = (e: React.MouseEvent) => {
    daySwipeStartRef.current = { x: e.clientX, y: e.clientY };
  };

  const onDayMouseUp = (e: React.MouseEvent) => {
    if (!daySwipeStartRef.current) return;
    const dx = e.clientX - daySwipeStartRef.current.x;
    const dy = e.clientY - daySwipeStartRef.current.y;
    daySwipeStartRef.current = null;

    if (Math.abs(dx) > 65 && Math.abs(dx) > Math.abs(dy) * 1.3) {
      if (dx > 0) {
        handleGoPrevDay();
      } else {
        handleGoNextDay();
      }
    }
  };

  // Generate Month Grid days
  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  const calendarDays: {
    dateStr: string;
    dayNum: number;
    isCurrentMonth: boolean;
    isToday: boolean;
    isSunday: boolean;
    isSaturday: boolean;
  }[] = [];

  // Previous month trailing days
  for (let i = firstDayOfMonth - 1; i >= 0; i--) {
    const d = daysInPrevMonth - i;
    const prevDate = new Date(year, month - 1, d);
    const dateStr = `${prevDate.getFullYear()}-${String(prevDate.getMonth() + 1).padStart(
      2,
      '0'
    )}-${String(prevDate.getDate()).padStart(2, '0')}`;
    const dayOfWeek = prevDate.getDay();
    calendarDays.push({
      dateStr,
      dayNum: d,
      isCurrentMonth: false,
      isToday: dateStr === todayStr,
      isSunday: dayOfWeek === 0,
      isSaturday: dayOfWeek === 6,
    });
  }

  // Current month days
  for (let d = 1; d <= daysInMonth; d++) {
    const currDate = new Date(year, month, d);
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const dayOfWeek = currDate.getDay();
    calendarDays.push({
      dateStr,
      dayNum: d,
      isCurrentMonth: true,
      isToday: dateStr === todayStr,
      isSunday: dayOfWeek === 0,
      isSaturday: dayOfWeek === 6,
    });
  }

  // Next month leading days
  const totalCells = calendarDays.length <= 35 ? 35 : 42;
  const remaining = totalCells - calendarDays.length;
  for (let d = 1; d <= remaining; d++) {
    const nextDate = new Date(year, month + 1, d);
    const dateStr = `${nextDate.getFullYear()}-${String(nextDate.getMonth() + 1).padStart(
      2,
      '0'
    )}-${String(nextDate.getDate()).padStart(2, '0')}`;
    const dayOfWeek = nextDate.getDay();
    calendarDays.push({
      dateStr,
      dayNum: d,
      isCurrentMonth: false,
      isToday: dateStr === todayStr,
      isSunday: dayOfWeek === 0,
      isSaturday: dayOfWeek === 6,
    });
  }

  // Filter events by active calendar
  const activeEvents = events.filter((e) => e.calendarId === activeCalendarId);

  // Group events by date (expanding multi-day / cross-day events across all spanned dates!)
  const eventsByDate = activeEvents.reduce((acc, ev) => {
    const spannedDates = getDatesInRange(ev.date, ev.endDate);
    spannedDates.forEach((dStr) => {
      if (!acc[dStr]) acc[dStr] = [];
      acc[dStr].push(ev);
    });
    return acc;
  }, {} as Record<string, CalendarEvent[]>);

  // Events on selected day
  const selectedDayEvents = eventsByDate[selectedDayDate] || [];

  // Select a date cell: shows that day's schedule list (never jumps straight to edit modal)
  const handleSelectDateCell = (dateStr: string) => {
    if (monthDidSwipeRef.current) {
      monthDidSwipeRef.current = false;
      return;
    }
    setSelectedDayDate(dateStr);
    setIsDayScheduleOpen(true);
  };

  // Format how time is shown on a specific day cell in the month grid
  const getCellTimeLabel = (ev: CalendarEvent, dayStr: string): string => {
    const isMultiDay = Boolean(ev.endDate && ev.endDate > ev.date);
    if (!isMultiDay) {
      return !ev.isAllDay && ev.startTime ? ev.startTime : '';
    }
    if (dayStr === ev.date) {
      return ev.isAllDay ? '初日' : `${ev.startTime || ''}〜`;
    }
    if (dayStr === ev.endDate) {
      return ev.isAllDay ? '最終日' : `〜${ev.endTime || ''}`;
    }
    return '終日';
  };

  // Format full date-time description for the Day Schedule panel
  const getFullEventTimeDisplay = (ev: CalendarEvent): string => {
    const isMultiDay = Boolean(ev.endDate && ev.endDate > ev.date);
    if (isMultiDay && ev.endDate) {
      const startPart = `${formatShortMonthDay(ev.date)}${
        !ev.isAllDay && ev.startTime ? ` ${ev.startTime}` : ''
      }`;
      const endPart = `${formatShortMonthDay(ev.endDate)}${
        !ev.isAllDay && ev.endTime ? ` ${ev.endTime}` : ''
      }`;
      return `${startPart} 〜 ${endPart}`;
    }
    if (ev.isAllDay) {
      return '終日';
    }
    return `${ev.startTime || '--:--'} 〜 ${ev.endTime || '--:--'}`;
  };

  // Render a clean event row inside the Daily Schedule List (Shows Title & Time; tapping opens Event Detail View)
  const renderDayEventCard = (ev: CalendarEvent, showDateBadge = false) => {
    const isMultiDay = Boolean(ev.endDate && ev.endDate > ev.date);

    return (
      <div
        key={`${ev.id}-${selectedDayDate}`}
        onClick={() => onSelectEvent(ev)}
        className="p-3.5 rounded-2xl border border-slate-200/90 hover:border-emerald-500 bg-white hover:bg-emerald-50/20 shadow-2xs transition flex items-center justify-between gap-3 cursor-pointer group"
      >
        {/* Left: Color Bar + Time + Title */}
        <div className="flex items-center gap-3 min-w-0 flex-1">
          {/* Vertical Color Accent Bar */}
          <div
            className="w-1.5 self-stretch rounded-full shrink-0"
            style={{ backgroundColor: ev.color }}
          />

          {/* Time Column */}
          <div className="w-24 sm:w-28 shrink-0 text-left">
            {showDateBadge && (
              <div className="text-[10px] font-bold text-slate-400 mb-0.5">
                {formatShortMonthDay(ev.date)}
              </div>
            )}
            <div className="flex items-center gap-1 text-xs font-extrabold text-slate-800">
              <Clock className="w-3 h-3 text-emerald-600 shrink-0" />
              <span className="truncate">{getFullEventTimeDisplay(ev)}</span>
            </div>
            {isMultiDay && (
              <span className="inline-block mt-0.5 text-[10px] font-bold text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded">
                日またぎ
              </span>
            )}
          </div>

          {/* Event Title & Brief Info */}
          <div className="min-w-0 flex-1 border-l border-slate-100 pl-3">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span
                className="text-[10px] font-bold px-2 py-0.5 rounded-md"
                style={{
                  backgroundColor: `${ev.color}18`,
                  color: ev.color,
                }}
              >
                {ev.category}
              </span>
              {ev.recurringGroupId && (
                <span className="inline-flex items-center gap-0.5 text-[10px] text-emerald-700 font-semibold">
                  <Repeat className="w-2.5 h-2.5" /> 繰り返し
                </span>
              )}
            </div>

            <h4 className="text-sm font-bold text-slate-900 truncate mt-1 group-hover:text-emerald-700 transition">
              {ev.title}
            </h4>

            {(ev.location || ev.notes) && (
              <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500 truncate">
                {ev.location && (
                  <span className="inline-flex items-center gap-0.5 truncate">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="truncate">{ev.location}</span>
                  </span>
                )}
                {ev.notes && (
                  <span className="truncate text-slate-400">
                    {ev.location ? `· ${ev.notes}` : ev.notes}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right: Members & Detail Chevron */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="hidden sm:flex -space-x-1.5">
            {ev.memberIds &&
              ev.memberIds.slice(0, 3).map((mId) => {
                const m = members.find((mem) => mem.id === mId);
                if (!m) return null;
                return (
                  <img
                    key={mId}
                    src={m.avatarUrl}
                    alt={m.name}
                    referrerPolicy="no-referrer"
                    className="w-5 h-5 rounded-full ring-2 ring-white object-cover"
                    title={m.name}
                  />
                );
              })}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400 group-hover:text-emerald-600 font-bold">
            {ev.checklist && ev.checklist.length > 0 && (
              <span className="flex items-center gap-0.5 text-slate-500">
                <CheckSquare className="w-3 h-3 text-emerald-600" />
                {ev.checklist.filter((c) => c.done).length}/{ev.checklist.length}
              </span>
            )}
            {ev.comments && ev.comments.length > 0 && (
              <span className="flex items-center gap-0.5 text-slate-500">
                <MessageCircle className="w-3 h-3 text-blue-500" />
                {ev.comments.length}
              </span>
            )}
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 overflow-hidden">
      {/* Calendar Top Sub-Header & Shift Quick Bar */}
      <div className="bg-white border-b border-slate-200 px-2.5 sm:px-4 py-2 shadow-2xs shrink-0">
        <div className="flex flex-wrap items-center justify-between gap-2 max-w-7xl mx-auto">
          {/* Row 1: Year Month & Month Navigation */}
          <div className="flex items-center justify-between w-full sm:w-auto gap-2">
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight whitespace-nowrap">
                {year}年 {month + 1}月
              </h2>
              <div className="flex items-center rounded-xl border border-slate-200 bg-slate-50 p-0.5 shadow-2xs">
                <button
                  type="button"
                  onClick={handlePrevMonth}
                  className="p-1.5 hover:bg-slate-200 rounded-lg text-slate-700 transition cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                  title="前月へ (右スワイプでも移動可)"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={handleToday}
                  className="px-2.5 py-1 text-xs font-bold text-slate-800 hover:bg-slate-200 rounded-lg transition cursor-pointer min-h-[32px]"
                >
                  今日
                </button>
                <button
                  type="button"
                  onClick={handleNextMonth}
                  className="p-1.5 hover:bg-slate-200 rounded-lg text-slate-700 transition cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                  title="次月へ (左スワイプでも移動可)"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Mobile Primary "+ 予定追加" Button */}
            <button
              type="button"
              onClick={() => onCreateEventAtDate(selectedDayDate || todayStr)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-xs transition cursor-pointer whitespace-nowrap min-h-[36px]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>予定追加</span>
            </button>
          </div>

          {/* Row 2: View Switcher & Shift Scanner Shortcut */}
          <div className="flex items-center justify-between sm:justify-end w-full sm:w-auto gap-2 border-t sm:border-t-0 border-slate-100 pt-1.5 sm:pt-0">
            <div className="inline-flex rounded-xl bg-slate-100 p-0.5 text-xs font-semibold shrink-0">
              <button
                type="button"
                onClick={() => setViewMode('month')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer whitespace-nowrap ${
                  viewMode === 'month'
                    ? 'bg-white shadow-2xs text-slate-900 font-extrabold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                月表示
              </button>
              <button
                type="button"
                onClick={() => setViewMode('agenda')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer whitespace-nowrap ${
                  viewMode === 'agenda'
                    ? 'bg-white shadow-2xs text-slate-900 font-extrabold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                予定一覧
              </button>
            </div>

            {onOpenRosterScanner && (
              <button
                type="button"
                onClick={onOpenRosterScanner}
                className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer whitespace-nowrap"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <span>シフト読取 (AI)</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Smartphone Visual Hint Bar */}
      <div className="bg-emerald-50/80 border-b border-emerald-100 px-3 py-1 text-center text-[11px] font-semibold text-emerald-800 shrink-0">
        💡 日付をタップするとその日の予定を確認・追加できます（左右スワイプで月切替）
      </div>

      {/* Main Content Split: Monthly Calendar Grid + Selected Day Schedule Panel */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        {viewMode === 'month' ? (
          /* Monthly Grid (Supports horizontal swipe/slide for Prev/Next Month) */
          <div
            onTouchStart={onMonthTouchStart}
            onTouchEnd={onMonthTouchEnd}
            onMouseDown={onMonthMouseDown}
            onMouseUp={onMonthMouseUp}
            className={`flex-1 flex flex-col bg-white overflow-hidden transition-transform duration-200 ${
              monthSlideDir === 'left'
                ? '-translate-x-2 opacity-90'
                : monthSlideDir === 'right'
                ? 'translate-x-2 opacity-90'
                : 'translate-x-0 opacity-100'
            }`}
          >
            {/* Weekday headers */}
            <div className="grid grid-cols-7 border-b border-slate-200 text-center py-1.5 text-xs font-bold bg-slate-50 shrink-0">
              <span className="text-red-500">日</span>
              <span className="text-slate-700">月</span>
              <span className="text-slate-700">火</span>
              <span className="text-slate-700">水</span>
              <span className="text-slate-700">木</span>
              <span className="text-slate-700">金</span>
              <span className="text-blue-500">土</span>
            </div>

            {/* Days Grid - Clicking ANYWHERE on a day cell opens that date's daily schedule */}
            <div className="flex-1 grid grid-cols-7 auto-rows-fr border-b border-slate-200 divide-x divide-y divide-slate-100 overflow-y-auto">
              {calendarDays.map((day) => {
                const dayEvents = eventsByDate[day.dateStr] || [];
                const isSelected = selectedDayDate === day.dateStr && isDayScheduleOpen;

                return (
                  <div
                    key={day.dateStr}
                    onClick={() => handleSelectDateCell(day.dateStr)}
                    className={`min-h-[58px] sm:min-h-[90px] p-1 flex flex-col transition cursor-pointer relative group select-none ${
                      !day.isCurrentMonth
                        ? 'bg-slate-50/60 text-slate-300'
                        : isSelected
                        ? 'bg-emerald-50/70 ring-2 ring-inset ring-emerald-500 z-10'
                        : 'bg-white hover:bg-slate-50/80'
                    }`}
                  >
                    {/* Date Number Header */}
                    <div className="flex items-center justify-between mb-0.5">
                      <span
                        className={`text-xs font-extrabold flex items-center justify-center w-5 h-5 sm:w-6 sm:h-6 rounded-full transition ${
                          day.isToday
                            ? 'bg-emerald-600 text-white shadow-2xs'
                            : isSelected
                            ? 'bg-emerald-100 text-emerald-900'
                            : day.isSunday
                            ? 'text-red-500'
                            : day.isSaturday
                            ? 'text-blue-500'
                            : day.isCurrentMonth
                            ? 'text-slate-700'
                            : 'text-slate-400'
                        }`}
                      >
                        {day.dayNum}
                      </span>

                      {dayEvents.length > 0 && (
                        <span className="text-[9px] sm:text-[10px] font-extrabold text-slate-400">
                          {dayEvents.length}件
                        </span>
                      )}
                    </div>

                    {/* Events Bars inside Day cell */}
                    <div className="flex-1 flex flex-col gap-0.5 sm:gap-1 overflow-hidden pointer-events-none">
                      {dayEvents.slice(0, 2).map((event) => {
                        const cellTime = getCellTimeLabel(event, day.dateStr);
                        return (
                          <div
                            key={`${event.id}-${day.dateStr}`}
                            className="px-1 py-0.5 text-[10px] sm:text-[11px] font-bold rounded-md truncate flex items-center gap-0.5 leading-tight"
                            style={{
                              backgroundColor: `${event.color}20`,
                              color: event.color,
                            }}
                          >
                            {cellTime && (
                              <span className="text-[8px] sm:text-[9px] opacity-90 shrink-0 font-mono hidden sm:inline">
                                {cellTime}
                              </span>
                            )}
                            <span className="truncate">{event.title}</span>
                          </div>
                        );
                      })}

                      {dayEvents.length > 2 && (
                        <span className="text-[9px] sm:text-[10px] text-slate-500 font-extrabold pl-0.5">
                          +{dayEvents.length - 2}件
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* Agenda / Full Schedule List View */
          <div className="flex-1 bg-white p-4 sm:p-5 overflow-y-auto space-y-3">
            <div className="flex items-center justify-between mb-3 pb-2.5 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setViewMode('month')}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>前の画面（月カレンダー）に戻る</span>
                </button>
                <h3 className="text-sm font-bold text-slate-800">
                  すべての予定一覧 ({activeEvents.length}件)
                </h3>
              </div>
            </div>
            {activeEvents.length === 0 ? (
              <div className="py-16 text-center text-slate-500 text-sm font-bold">
                予定がありません。
              </div>
            ) : (
              [...activeEvents]
                .sort((a, b) => a.date.localeCompare(b.date))
                .map((ev) => renderDayEventCard(ev, true))
            )}
          </div>
        )}

        {/* Selected Day Schedule Screen / Panel (Supports horizontal swipe/slide for Prev/Next Day) */}
        {isDayScheduleOpen && (
          <div
            onTouchStart={onDayTouchStart}
            onTouchEnd={onDayTouchEnd}
            onMouseDown={onDayMouseDown}
            onMouseUp={onDayMouseUp}
            className={`fixed inset-x-0 bottom-16 sm:bottom-0 top-12 z-40 lg:static lg:w-[420px] lg:h-full bg-white border-t lg:border-t-0 lg:border-l border-slate-200 flex flex-col shrink-0 shadow-2xl lg:shadow-none transition-transform duration-150 rounded-t-3xl lg:rounded-none ${
              daySlideDir === 'left'
                ? '-translate-x-2 opacity-90'
                : daySlideDir === 'right'
                ? 'translate-x-2 opacity-90'
                : 'translate-x-0 opacity-100'
            }`}
          >
            {/* Mobile Sheet Drag Handle Indicator */}
            <div className="w-10 h-1.5 bg-slate-300 rounded-full mx-auto my-2 lg:hidden shrink-0" />

            {/* Top Bar of Day Schedule Panel */}
            <div className="px-4 py-2.5 border-b border-slate-200 bg-slate-50 space-y-2 shrink-0">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <CalendarIcon className="w-4 h-4 text-emerald-600" />
                  <span>選択した日の予定一覧</span>
                </span>

                <span className="text-[11px] text-slate-400 font-medium">
                  左右スワイプで前日・翌日へ
                </span>

                <button
                  type="button"
                  onClick={() => onCreateEventAtDate(selectedDayDate)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1 cursor-pointer min-h-[36px]"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>予定追加</span>
                </button>
              </div>

              {/* Selected Date Title + Prev/Next Day Switcher */}
              <div className="flex items-center justify-between gap-1.5 bg-white p-2 rounded-xl border border-slate-200/90 shadow-2xs">
                <button
                  type="button"
                  onClick={handleGoPrevDay}
                  className="px-2 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-900 rounded-lg text-xs font-bold flex items-center gap-0.5 transition cursor-pointer shrink-0 shadow-2xs min-h-[38px]"
                  title="前日の予定へ移動"
                >
                  <ChevronLeft className="w-4 h-4 text-emerald-600" />
                  <span>前日</span>
                </button>

                <div className="text-center min-w-0 px-1 flex-1">
                  <div className="text-[10px] font-bold text-emerald-700">
                    {selectedDayEvents.length > 0
                      ? `${selectedDayEvents.length}件の予定`
                      : '予定なし'}
                  </div>
                  <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 truncate">
                    {selectedDayDate
                      ? new Date(selectedDayDate + 'T00:00:00').toLocaleDateString('ja-JP', {
                          month: 'long',
                          day: 'numeric',
                          weekday: 'short',
                        })
                      : '日付を選択'}
                  </h3>
                </div>

                <button
                  type="button"
                  onClick={handleGoNextDay}
                  className="px-2 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-900 rounded-lg text-xs font-bold flex items-center gap-0.5 transition cursor-pointer shrink-0 shadow-2xs min-h-[38px]"
                  title="翌日の予定へ移動"
                >
                  <span>翌日</span>
                  <ChevronRight className="w-4 h-4 text-emerald-600" />
                </button>
              </div>
            </div>

            {/* Events list for the selected day */}
            <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2.5 bg-slate-50/40">
              {selectedDayEvents.length === 0 ? (
                <div className="py-12 text-center bg-white rounded-2xl border border-dashed border-slate-200 p-5">
                  <CalendarIcon className="w-8 h-8 mx-auto mb-2 text-slate-300 stroke-1" />
                  <p className="text-xs sm:text-sm font-bold text-slate-600">
                    予定がありません。
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    左右にスワイプして前日・翌日の予定を確認できます
                  </p>
                  <button
                    type="button"
                    onClick={() => onCreateEventAtDate(selectedDayDate)}
                    className="mt-3 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition inline-flex items-center gap-1.5 shadow-2xs cursor-pointer min-h-[40px]"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    この日に予定を作成する
                  </button>
                </div>
              ) : (
                <>
                  <div className="text-[10px] sm:text-[11px] font-semibold text-slate-500 px-1 flex items-center justify-between">
                    <span>予定をタップすると詳細（日時・備考など）を開きます</span>
                  </div>
                  {selectedDayEvents.map((ev) => renderDayEventCard(ev))}
                </>
              )}
            </div>

            {/* Bottom Footer Bar with Single "Back to Previous Screen (Calendar)" Button */}
            <div className="p-3 bg-white border-t border-slate-200 flex items-center justify-between gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsDayScheduleOpen(false)}
                className="flex-1 py-2.5 px-4 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs min-h-[44px]"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>前の画面（カレンダー）に戻る</span>
              </button>
              <button
                type="button"
                onClick={() => onCreateEventAtDate(selectedDayDate)}
                className="py-2.5 px-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 shadow-xs transition cursor-pointer min-h-[44px]"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden sm:inline">予定追加</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
