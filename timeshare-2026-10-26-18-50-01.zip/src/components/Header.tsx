import React from 'react';
import { User } from 'firebase/auth';
import {
  Calendar as CalendarIcon,
  MapPin,
  Share2,
  ChevronDown,
  CheckCircle2,
  FileSpreadsheet,
  RefreshCw,
  UserPlus,
  Lock,
  Plus,
} from 'lucide-react';
import { SharedCalendar, Member } from '../types';

interface HeaderProps {
  calendars: SharedCalendar[];
  activeCalendar: SharedCalendar;
  onSelectCalendar: (calendarId: string) => void;
  activeView: 'calendar' | 'map';
  onChangeView: (view: 'calendar' | 'map') => void;
  onOpenRosterScanner: () => void;
  onOpenShareModal: () => void;
  onOpenCreateCalendar?: () => void;
  onOpenGoogleSyncModal: () => void;
  onOpenUserModal: () => void;
  onManualRefresh: () => void;
  isRefreshing?: boolean;
  isLiveConnected?: boolean;
  lastSyncedLabel?: string;
  onlineCount?: number;
  googleUser: User | null;
  members: Member[];
  currentMember: Member;
  onSwitchMember: (memberId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  calendars,
  activeCalendar,
  onSelectCalendar,
  activeView,
  onChangeView,
  onOpenRosterScanner,
  onOpenShareModal,
  onOpenCreateCalendar,
  onOpenGoogleSyncModal,
  onOpenUserModal,
  onManualRefresh,
  isRefreshing = false,
  isLiveConnected = true,
  lastSyncedLabel = '',
  googleUser,
  members,
  currentMember,
  onSwitchMember,
}) => {
  return (
    <>
      {/* Top Header Bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-2xs shrink-0">
        <div className="max-w-7xl mx-auto px-2.5 sm:px-4 py-2 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
          {/* Left: Brand & Active Calendar Selector */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <div className="flex items-center gap-1.5 shrink-0">
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-xs shrink-0">
                <CalendarIcon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </div>
              <span className="font-extrabold text-slate-900 tracking-tight text-sm sm:text-base whitespace-nowrap">
                Time<span className="text-emerald-600">Share</span>
              </span>
            </div>

            <div className="h-4 w-[1px] bg-slate-200 hidden sm:block shrink-0" />

            {/* Active Calendar Switcher */}
            <div className="relative shrink-0">
              <select
                value={activeCalendar.id}
                onChange={(e) => {
                  if (e.target.value === '__CREATE_NEW__') {
                    onOpenCreateCalendar?.();
                  } else {
                    onSelectCalendar(e.target.value);
                  }
                }}
                className="appearance-none pl-2 pr-6 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 cursor-pointer transition focus:outline-hidden max-w-[130px] sm:max-w-[200px] truncate"
              >
                {calendars.map((cal) => (
                  <option key={cal.id} value={cal.id}>
                    {cal.emoji} {cal.name}
                  </option>
                ))}
                <option value="__CREATE_NEW__">＋ 新規作成...</option>
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-1.5 top-2.5 pointer-events-none" />
            </div>

            {/* Desktop Direct "＋ 新しいカレンダーを作成" Button */}
            <button
              type="button"
              onClick={onOpenCreateCalendar}
              className="hidden md:flex px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold items-center gap-1 transition shadow-xs whitespace-nowrap shrink-0 cursor-pointer"
              title="新しい共有カレンダーを作成"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>新規カレンダー</span>
            </button>
          </div>

          {/* Desktop Center: Main View Navigation */}
          <div className="hidden md:inline-flex rounded-xl bg-slate-100 p-1 text-xs font-semibold shadow-inner shrink-0">
            <button
              type="button"
              onClick={() => onChangeView('calendar')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition whitespace-nowrap shrink-0 cursor-pointer ${
                activeView === 'calendar'
                  ? 'bg-white text-emerald-800 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CalendarIcon className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>共有カレンダー</span>
            </button>
            <button
              type="button"
              onClick={() => onChangeView('map')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition whitespace-nowrap shrink-0 cursor-pointer ${
                activeView === 'map'
                  ? 'bg-white text-emerald-800 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>行きたい場所・地図</span>
            </button>
          </div>

          {/* Right Action Tools */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Real-time Refresh / Sync Button */}
            <button
              type="button"
              onClick={onManualRefresh}
              disabled={isRefreshing}
              className="px-2 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-1 transition whitespace-nowrap shrink-0 cursor-pointer min-h-[38px]"
              title={`リアルタイム同期中${lastSyncedLabel ? ` (最終同期: ${lastSyncedLabel})` : ''}`}
            >
              <RefreshCw
                className={`w-3.5 h-3.5 text-emerald-600 shrink-0 ${
                  isRefreshing ? 'animate-spin' : ''
                }`}
              />
              <span className="hidden sm:inline">更新</span>
              <span className="flex items-center gap-1 text-[10px] font-semibold bg-white/90 px-1.5 py-0.2 rounded-full border border-emerald-200 text-emerald-700">
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    isLiveConnected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'
                  }`}
                />
                <span className="hidden sm:inline">同期ON</span>
              </span>
            </button>

            {/* Desktop Shift Scanner button */}
            <button
              type="button"
              onClick={onOpenRosterScanner}
              className="hidden sm:flex px-2.5 py-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl text-xs font-bold items-center gap-1 transition shadow-xs whitespace-nowrap shrink-0 cursor-pointer min-h-[38px]"
              title="勤務表・シフト表の写真・PDF読取"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-white shrink-0" />
              <span>シフト読取</span>
            </button>

            {/* Desktop Share Calendar button */}
            <button
              type="button"
              onClick={onOpenShareModal}
              className="hidden lg:flex px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-xl text-xs font-semibold items-center gap-1 transition whitespace-nowrap shrink-0 cursor-pointer min-h-[38px]"
            >
              <Share2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>共有</span>
            </button>

            {/* Google Calendar Sync button */}
            <button
              type="button"
              onClick={onOpenGoogleSyncModal}
              className={`hidden md:flex px-2 py-1.5 rounded-xl text-xs font-semibold items-center gap-1 border transition whitespace-nowrap shrink-0 cursor-pointer min-h-[38px] ${
                googleUser
                  ? 'bg-blue-50/80 border-blue-200 text-blue-800'
                  : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}
              title="Google同期"
            >
              <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              {googleUser && <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />}
            </button>

            {/* User Switcher Dropdown */}
            <div className="relative shrink-0">
              <select
                value={currentMember.id}
                onChange={(e) => onSwitchMember(e.target.value)}
                className="appearance-none pl-5 pr-5 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-full text-xs font-bold text-slate-800 cursor-pointer transition focus:outline-hidden max-w-[100px] sm:max-w-[140px] truncate min-h-[38px]"
                title="操作ユーザー切替"
              >
                {members.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.isPasswordProtected ? '🔒 ' : ''}
                    {m.name}
                  </option>
                ))}
              </select>
              <span
                className="w-2 h-2 rounded-full absolute left-2 top-3.5 pointer-events-none"
                style={{ backgroundColor: currentMember.color }}
              />
              <ChevronDown className="w-3 h-3 text-slate-400 absolute right-1.5 top-3.5 pointer-events-none" />
            </div>

            {/* Desktop Dedicated User Add & Password Settings Button */}
            <button
              type="button"
              onClick={onOpenUserModal}
              className="hidden sm:flex px-2.5 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-full text-xs font-bold items-center gap-1 transition shadow-xs whitespace-nowrap shrink-0 cursor-pointer min-h-[38px]"
              title="ユーザー追加・設定"
            >
              <UserPlus className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="hidden lg:inline">ユーザー追加</span>
              {currentMember.isPasswordProtected && (
                <Lock className="w-3 h-3 text-amber-300 shrink-0" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Fixed Bottom Navigation Bar (Thumb-Zone Pattern 1 for Smartphones) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 h-16 flex items-center justify-around px-1 shadow-lg pb-safe">
        <button
          type="button"
          onClick={() => onChangeView('calendar')}
          className={`flex-1 flex flex-col items-center justify-center h-full min-h-[44px] transition cursor-pointer ${
            activeView === 'calendar' ? 'text-emerald-600 font-extrabold' : 'text-slate-500 font-medium'
          }`}
        >
          <CalendarIcon className={`w-5 h-5 ${activeView === 'calendar' ? 'text-emerald-600' : 'text-slate-500'}`} />
          <span className="text-[10px] tracking-tight mt-1">カレンダー</span>
        </button>

        <button
          type="button"
          onClick={() => onChangeView('map')}
          className={`flex-1 flex flex-col items-center justify-center h-full min-h-[44px] transition cursor-pointer ${
            activeView === 'map' ? 'text-emerald-600 font-extrabold' : 'text-slate-500 font-medium'
          }`}
        >
          <MapPin className={`w-5 h-5 ${activeView === 'map' ? 'text-emerald-600' : 'text-slate-500'}`} />
          <span className="text-[10px] tracking-tight mt-1">マップ・場所</span>
        </button>

        <button
          type="button"
          onClick={onOpenRosterScanner}
          className="flex-1 flex flex-col items-center justify-center h-full min-h-[44px] text-amber-600 font-bold transition cursor-pointer"
        >
          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-white flex items-center justify-center shadow-xs">
            <FileSpreadsheet className="w-4 h-4" />
          </div>
          <span className="text-[10px] tracking-tight mt-0.5">シフト読取</span>
        </button>

        <button
          type="button"
          onClick={onOpenShareModal}
          className="flex-1 flex flex-col items-center justify-center h-full min-h-[44px] text-slate-600 font-medium transition cursor-pointer hover:text-emerald-600"
        >
          <Share2 className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">共有・作成</span>
        </button>

        <button
          type="button"
          onClick={onOpenUserModal}
          className="flex-1 flex flex-col items-center justify-center h-full min-h-[44px] text-slate-600 font-medium transition cursor-pointer hover:text-slate-900"
        >
          <UserPlus className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">ユーザー設定</span>
        </button>
      </nav>
    </>
  );
};
