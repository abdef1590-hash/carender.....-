import React, { useState, useEffect, useRef } from 'react';
import L from 'leaflet';
import {
  MapPin,
  Search,
  Plus,
  Navigation,
  Star,
  CheckCircle2,
  Calendar,
  Trash2,
  Compass,
  CloudSun,
  ShieldCheck,
  AlertTriangle,
  Wind,
  Droplets,
  Sparkles,
  X,
  BookmarkPlus,
  Check,
} from 'lucide-react';
import {
  PinnedPlace,
  PlaceCategory,
  SharedCalendar,
  PlaceWeatherDisaster,
} from '../types';
import { searchPlacesReliably, PlaceSearchResult, getPlacePhotoUrl } from '../lib/placesSearch';

interface MapAndPlacesViewProps {
  places: PinnedPlace[];
  calendars: SharedCalendar[];
  activeCalendarId: string;
  onAddPlace: (place: Omit<PinnedPlace, 'id'>) => void;
  onUpdatePlace: (place: PinnedPlace) => void;
  onDeletePlace: (id: string) => void;
  onCreateEventFromPlace: (place: PinnedPlace) => void;
}

const CATEGORY_CONFIG: Record<
  PlaceCategory,
  { label: string; emoji: string; color: string; bg: string }
> = {
  cafe: { label: 'カフェ', emoji: '☕', color: '#B45309', bg: '#FEF3C7' },
  gourmet: { label: 'グルメ・食事', emoji: '🍽️', color: '#DC2626', bg: '#FEE2E2' },
  sightseeing: { label: '観光・おでかけ', emoji: '🗼', color: '#2563EB', bg: '#DBEAFE' },
  shopping: { label: '買い物', emoji: '🛍️', color: '#7C3AED', bg: '#EDE9FE' },
  stay: { label: '宿泊・ホテル', emoji: '🏨', color: '#059669', bg: '#D1FAE5' },
  nature: { label: '自然・景勝地', emoji: '🌲', color: '#16A34A', bg: '#DCFCE7' },
  other: { label: 'その他', emoji: '📍', color: '#4B5563', bg: '#F3F4F6' },
};

const POPULAR_QUICK_SEARCHES = [
  { label: 'スターバックス', emoji: '☕' },
  { label: 'bills お台場', emoji: '🥞' },
  { label: '東京タワー', emoji: '🗼' },
  { label: '一蘭 渋谷', emoji: '🍜' },
  { label: 'SHIBUYA SKY', emoji: '🏙️' },
  { label: 'チームラボ 豊洲', emoji: '🎆' },
  { label: '草津温泉 湯畑', emoji: '♨️' },
  { label: 'ディズニーランド', emoji: '🎡' },
];

export const MapAndPlacesView: React.FC<MapAndPlacesViewProps> = ({
  places,
  activeCalendarId,
  onAddPlace,
  onUpdatePlace,
  onDeletePlace,
  onCreateEventFromPlace,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker }>({});
  const previewMarkerRef = useRef<L.Marker | null>(null);

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [filterVisited, setFilterVisited] = useState<'all' | 'unvisited' | 'visited'>('all');

  // Search States
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<PlaceSearchResult[]>([]);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [previewPlace, setPreviewPlace] = useState<PlaceSearchResult | null>(null);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  const [selectedPlace, setSelectedPlace] = useState<PinnedPlace | null>(null);

  // Weather & Disaster Modal state
  const [weatherPlace, setWeatherPlace] = useState<{ name: string; lat: number; lng: number } | null>(null);
  const [weatherData, setWeatherData] = useState<PlaceWeatherDisaster | null>(null);
  const [isLoadingWeather, setIsLoadingWeather] = useState(false);
  const [weatherError, setWeatherError] = useState<string | null>(null);

  // New Place modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalForm, setModalForm] = useState({
    name: '',
    category: 'cafe' as PlaceCategory,
    lat: 35.6812,
    lng: 139.7671,
    address: '東京都千代田区丸の内1丁目',
    notes: '',
    budget: '',
    rating: 5,
    targetDate: '',
    url: '',
    imageUrl: '',
  });

  // Debounced auto-search as user types
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      setShowSearchResults(false);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const results = await searchPlacesReliably(searchQuery);
        setSearchResults(results);
        setShowSearchResults(true);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setIsSearching(false);
      }
    }, 280);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Filter places
  const filteredPlaces = places.filter((p) => {
    if (selectedCategory !== 'all' && p.category !== selectedCategory) return false;
    if (filterVisited === 'unvisited' && p.isVisited) return false;
    if (filterVisited === 'visited' && !p.isVisited) return false;
    return true;
  });

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const initialLat = places.length > 0 ? places[0].lat : 35.6812;
      const initialLng = places.length > 0 ? places[0].lng : 139.7671;

      const map = L.map(mapContainerRef.current, {
        center: [initialLat, initialLng],
        zoom: 12,
        zoomControl: false,
      });

      L.control.zoom({ position: 'bottomright' }).addTo(map);

      // OpenStreetMap Tiles
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(map);

      // Click map to drop pin and open modal
      map.on('click', async (e: L.LeafletMouseEvent) => {
        const { lat, lng } = e.latlng;
        let detectedAddress = `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
        try {
          const res = await fetch(`/api/places/reverse?lat=${lat}&lng=${lng}`);
          if (res.ok) {
            const data = await res.json();
            if (data.displayName) {
              detectedAddress = data.displayName;
            }
          }
        } catch {
          // fallback to coordinate string
        }

        setModalForm({
          name: '',
          category: 'cafe',
          lat,
          lng,
          address: detectedAddress,
          notes: '',
          budget: '',
          rating: 5,
          targetDate: '',
          url: '',
          imageUrl: '',
        });
        setIsModalOpen(true);
      });

      mapInstanceRef.current = map;
    }
  }, []);

  // Update Markers when filteredPlaces changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear previous markers
    Object.values(markersRef.current).forEach((marker) => marker.remove());
    markersRef.current = {};

    filteredPlaces.forEach((place) => {
      const config = CATEGORY_CONFIG[place.category] || CATEGORY_CONFIG.other;

      const customIcon = L.divIcon({
        className: 'custom-map-pin',
        html: `
          <div style="
            display: flex;
            align-items: center;
            justify-content: center;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: ${place.isVisited ? '#64748b' : config.color};
            color: white;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            border: 2px solid white;
            font-size: 18px;
            cursor: pointer;
            transition: transform 0.2s;
          ">
            ${config.emoji}
          </div>
        `,
        iconSize: [38, 38],
        iconAnchor: [19, 19],
      });

      const marker = L.marker([place.lat, place.lng], { icon: customIcon }).addTo(map);

      // Popup
      const popupHtml = `
        <div style="font-family: inherit; min-width: 220px; max-width: 260px; padding: 4px;">
          ${
            place.imageUrl
              ? `<div style="height: 100px; width: 100%; overflow: hidden; border-radius: 8px; margin-bottom: 6px;">
                   <img src="${place.imageUrl}" alt="${place.name}" style="width: 100%; height: 100%; object-fit: cover;" />
                 </div>`
              : ''
          }
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
            <span style="font-size: 16px;">${config.emoji}</span>
            <strong style="font-size: 14px; color: #1e293b;">${place.name}</strong>
          </div>
          <p style="font-size: 11px; color: #64748b; margin: 0 0 6px 0;">${place.address}</p>
          ${place.notes ? `<p style="font-size: 11px; color: #334155; margin: 0 0 8px 0; background: #f8fafc; padding: 4px 8px; border-radius: 6px;">${place.notes}</p>` : ''}
          <div style="display: flex; gap: 4px; margin-top: 8px;">
            <button id="btn-weather-${place.id}" style="
              font-size: 11px;
              color: #0369a1;
              background: #e0f2fe;
              border: 1px solid #bae6fd;
              padding: 4px 8px;
              border-radius: 6px;
              cursor: pointer;
              font-weight: 600;
            ">
              ☀️ 天気・防災
            </button>
            <a href="https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(place.address || `${place.lat},${place.lng}`)}" target="_blank" rel="noopener noreferrer" style="
              font-size: 11px;
              color: white;
              background: #2563eb;
              padding: 4px 8px;
              border-radius: 6px;
              text-decoration: none;
              font-weight: 600;
            ">
              経路
            </a>
          </div>
        </div>
      `;
      marker.bindPopup(popupHtml);

      marker.on('popupopen', () => {
        const btn = document.getElementById(`btn-weather-${place.id}`);
        if (btn) {
          btn.onclick = () => {
            fetchWeatherAndDisaster(place.name, place.lat, place.lng);
          };
        }
      });

      marker.on('click', () => {
        setSelectedPlace(place);
      });

      markersRef.current[place.id] = marker;
    });
  }, [filteredPlaces]);

  // Execute manual search submit
  const handleSearchSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    setShowSearchResults(true);
    try {
      const results = await searchPlacesReliably(searchQuery.trim());
      setSearchResults(results);
      if (results.length > 0) {
        handleSelectSearchCandidate(results[0]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  // Select Search Candidate
  const handleSelectSearchCandidate = (candidate: PlaceSearchResult) => {
    setShowSearchResults(false);
    setPreviewPlace(candidate);

    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([candidate.lat, candidate.lng], 15, { duration: 1.2 });

      // Remove previous preview marker
      if (previewMarkerRef.current) {
        previewMarkerRef.current.remove();
      }

      // Add temporary high-visibility pulsing preview marker
      const cfg = CATEGORY_CONFIG[candidate.category] || CATEGORY_CONFIG.other;
      const previewIcon = L.divIcon({
        className: 'preview-map-pin',
        html: `
          <div style="
            display: flex;
            align-items: center;
            justify-content: center;
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: #dc2626;
            color: white;
            box-shadow: 0 0 0 6px rgba(220, 38, 38, 0.3), 0 6px 16px rgba(0,0,0,0.4);
            border: 3px solid white;
            font-size: 22px;
            animation: pulse 1.5s infinite;
          ">
            ${cfg.emoji}
          </div>
        `,
        iconSize: [44, 44],
        iconAnchor: [22, 22],
      });

      const marker = L.marker([candidate.lat, candidate.lng], { icon: previewIcon }).addTo(
        mapInstanceRef.current
      );
      previewMarkerRef.current = marker;
    }

    // Auto-fetch weather for this search candidate
    fetchWeatherAndDisaster(candidate.name, candidate.lat, candidate.lng);
  };

  // 1-Click Save Preview Place to Pinned Places
  const handleSavePreviewPlace = () => {
    if (!previewPlace) return;

    onAddPlace({
      calendarId: activeCalendarId,
      name: previewPlace.name,
      category: previewPlace.category,
      lat: previewPlace.lat,
      lng: previewPlace.lng,
      address: previewPlace.address,
      notes: previewPlace.notes,
      budget: previewPlace.budget,
      rating: 5,
      imageUrl: previewPlace.imageUrl || getPlacePhotoUrl(previewPlace.name, previewPlace.category),
      isVisited: false,
      createdBy: '自分',
    });

    setSaveSuccessMsg(`「${previewPlace.name}」を行きたい場所リストに保存しました！`);
    setTimeout(() => setSaveSuccessMsg(null), 3000);
  };

  // Fetch Live Weather & Disaster Safety Info
  const fetchWeatherAndDisaster = async (name: string, lat: number, lng: number) => {
    setWeatherPlace({ name, lat, lng });
    setIsLoadingWeather(true);
    setWeatherError(null);
    setWeatherData(null);

    try {
      const res = await fetch('/api/places/weather-disaster', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lat, lng, placeName: name }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || '天気・防災情報の取得に失敗しました。');
      }

      setWeatherData(data.data);
    } catch (err: any) {
      console.error(err);
      setWeatherError(err.message || '天気情報を取得できませんでした。');
    } finally {
      setIsLoadingWeather(false);
    }
  };

  const handleSaveModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalForm.name.trim()) return;

    const resolvedPhoto = modalForm.imageUrl.trim() || getPlacePhotoUrl(modalForm.name, modalForm.category);

    onAddPlace({
      calendarId: activeCalendarId,
      name: modalForm.name.trim(),
      category: modalForm.category,
      lat: modalForm.lat,
      lng: modalForm.lng,
      address: modalForm.address,
      notes: modalForm.notes.trim() || undefined,
      budget: modalForm.budget.trim() || undefined,
      rating: modalForm.rating,
      targetDate: modalForm.targetDate || undefined,
      url: modalForm.url.trim() || undefined,
      imageUrl: resolvedPhoto || undefined,
      isVisited: false,
      createdBy: '自分',
    });

    setIsModalOpen(false);

    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([modalForm.lat, modalForm.lng], 14);
    }
  };

  const jumpToPlace = (place: PinnedPlace) => {
    setSelectedPlace(place);
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([place.lat, place.lng], 15, { duration: 1 });
      const marker = markersRef.current[place.id];
      if (marker) {
        marker.openPopup();
      }
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 relative">
      {/* Top Action Bar with Real-Time Google Maps Style Search */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 shadow-xs relative z-40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 max-w-7xl mx-auto">
          {/* Search bar with real-time dropdown results */}
          <div className="flex-1 max-w-lg relative">
            <form onSubmit={handleSearchSubmit} className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => {
                  if (searchResults.length > 0) setShowSearchResults(true);
                }}
                placeholder="Googleマップのようにお店・カフェ・観光地を検索 (例: スターバックス 渋谷、bills)"
                className="w-full pl-10 pr-24 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery('');
                    setSearchResults([]);
                    setShowSearchResults(false);
                    setPreviewPlace(null);
                    if (previewMarkerRef.current) previewMarkerRef.current.remove();
                  }}
                  className="absolute right-20 top-2.5 text-slate-400 hover:text-slate-600 text-xs p-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                type="submit"
                disabled={isSearching}
                className="absolute right-1.5 top-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 shadow-2xs cursor-pointer"
              >
                {isSearching ? (
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Search className="w-3 h-3" />
                )}
                <span>検索</span>
              </button>
            </form>

            {/* Candidates Search Dropdown */}
            {showSearchResults && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-[4500] animate-in fade-in zoom-in-95 duration-100 max-h-80 overflow-y-auto">
                <div className="p-2.5 bg-slate-50 border-b border-slate-100 text-[11px] font-bold text-slate-500 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    検索候補（クリックで地図にジャンプ＆天気・防災表示）
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowSearchResults(false)}
                    className="text-slate-400 hover:text-slate-600 p-1"
                  >
                    ✕
                  </button>
                </div>

                {isSearching ? (
                  <div className="p-5 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
                    <div className="w-4 h-4 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
                    店舗・施設を検索中...
                  </div>
                ) : searchResults.length === 0 ? (
                  <div className="p-5 text-center text-xs text-slate-400">
                    該当する店舗が見つかりませんでした。「スターバックス」「東京タワー」「一蘭」などで検索してみてください。
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {searchResults.map((res, idx) => {
                      const cfg = CATEGORY_CONFIG[res.category] || CATEGORY_CONFIG.other;
                      return (
                        <div
                          key={idx}
                          onClick={() => handleSelectSearchCandidate(res)}
                          className="p-3 hover:bg-emerald-50/60 cursor-pointer transition flex items-center justify-between gap-3 group"
                        >
                          <div className="flex items-center gap-3">
                            {res.imageUrl ? (
                              <img
                                src={res.imageUrl}
                                alt={res.name}
                                className="w-12 h-12 rounded-xl object-cover shrink-0 border border-slate-200 shadow-2xs group-hover:scale-105 transition"
                              />
                            ) : (
                              <span className="text-xl p-2 bg-slate-100 group-hover:bg-white rounded-xl shrink-0">
                                {cfg.emoji}
                              </span>
                            )}
                            <div>
                              <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                                {res.name}
                                <span
                                  className="text-[10px] px-1.5 py-0.2 rounded-full font-medium"
                                  style={{ backgroundColor: cfg.bg, color: cfg.color }}
                                >
                                  {cfg.label}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                                {res.address}
                              </p>
                              {res.notes && (
                                <p className="text-[10px] text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded-sm mt-0.5 inline-block">
                                  {res.notes}
                                </p>
                              )}
                            </div>
                          </div>

                          <span className="px-2.5 py-1 bg-emerald-600 group-hover:bg-emerald-700 text-white rounded-lg text-[11px] font-semibold shrink-0 shadow-2xs">
                            選択
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Quick Popular Search Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
            <span className="text-[11px] font-bold text-slate-400 shrink-0">人気:</span>
            {POPULAR_QUICK_SEARCHES.map((chip, cIdx) => (
              <button
                key={cIdx}
                type="button"
                onClick={() => {
                  setSearchQuery(chip.label);
                  handleSearchSubmit();
                }}
                className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-200 border border-slate-200 rounded-lg text-xs font-medium transition shrink-0 flex items-center gap-1"
              >
                <span>{chip.emoji}</span>
                <span>{chip.label}</span>
              </button>
            ))}
          </div>

          {/* Filters & Manual add */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0 shrink-0">
            <button
              type="button"
              onClick={() => {
                setModalForm({
                  name: '',
                  category: 'cafe',
                  lat: 35.6812,
                  lng: 139.7671,
                  address: '東京都千代田区丸の内1丁目',
                  notes: '',
                  budget: '',
                  rating: 5,
                  targetDate: '',
                  url: '',
                  imageUrl: '',
                });
                setIsModalOpen(true);
              }}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-xs transition shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              手動登録
            </button>
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pt-2.5 max-w-7xl mx-auto scrollbar-none">
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1 rounded-full text-xs font-medium transition shrink-0 ${
              selectedCategory === 'all'
                ? 'bg-slate-800 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            全ジャンル
          </button>
          {Object.entries(CATEGORY_CONFIG).map(([key, cfg]) => (
            <button
              key={key}
              type="button"
              onClick={() => setSelectedCategory(key)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition shrink-0 flex items-center gap-1 ${
                selectedCategory === key
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <span>{cfg.emoji}</span>
              <span>{cfg.label}</span>
            </button>
          ))}
        </div>
      </div>

      {saveSuccessMsg && (
        <div className="absolute top-24 left-1/2 -translate-x-1/2 z-[3000] bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-xl flex items-center gap-2 animate-in fade-in slide-in-from-top-4">
          <Check className="w-4 h-4" />
          <span>{saveSuccessMsg}</span>
        </div>
      )}

      {/* Main split: Map and Places Cards */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        {/* Leaflet Map Area */}
        <div className="w-full lg:w-7/12 h-[380px] lg:h-full relative z-0">
          <div ref={mapContainerRef} className="w-full h-full" />
          <div className="absolute top-3 left-3 z-[1000] bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-lg shadow-sm border border-slate-200 text-xs text-slate-600 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-emerald-600" />
            地図上をクリックしてどこでもピン留め可能
          </div>

          {/* Floating Google-Maps-Style Searched Spot Card */}
          {previewPlace && (
            <div className="absolute bottom-4 left-4 right-4 sm:right-auto sm:max-w-md z-[1200] bg-white rounded-2xl shadow-2xl border-2 border-emerald-500 p-4 animate-in fade-in slide-in-from-bottom-4 overflow-hidden">
              {previewPlace.imageUrl && (
                <div className="h-32 -mx-4 -mt-4 mb-3 relative overflow-hidden bg-slate-100">
                  <img
                    src={previewPlace.imageUrl}
                    alt={previewPlace.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  <span className="absolute bottom-2 left-3 text-xs font-bold text-white drop-shadow-md flex items-center gap-1">
                    📷 現地の写真・イメージ
                  </span>
                </div>
              )}

              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-2xl p-1 bg-slate-100 rounded-lg shrink-0">
                    {CATEGORY_CONFIG[previewPlace.category]?.emoji || '📍'}
                  </span>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{previewPlace.name}</h3>
                    <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                      {previewPlace.address}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setPreviewPlace(null);
                    if (previewMarkerRef.current) previewMarkerRef.current.remove();
                  }}
                  className="text-slate-400 hover:text-slate-600 p-1"
                >
                  ✕
                </button>
              </div>

              {/* Weather Chip Preview */}
              {weatherData && (
                <div
                  onClick={() => fetchWeatherAndDisaster(previewPlace.name, previewPlace.lat, previewPlace.lng)}
                  className={`mt-2 p-2 rounded-xl border flex items-center justify-between text-xs cursor-pointer transition ${
                    weatherData.disaster.overallStatus === 'safe'
                      ? 'bg-sky-50 border-sky-200 text-sky-900'
                      : 'bg-amber-50 border-amber-200 text-amber-950'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{weatherData.current.emoji}</span>
                    <span className="font-bold">{weatherData.current.temp}°C {weatherData.current.weatherLabel}</span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/80 border border-current">
                    {weatherData.disaster.overallStatus === 'safe' ? '🟢 安全・警報なし' : '🟡 注意報・要確認'}
                  </span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center gap-2 mt-3 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleSavePreviewPlace}
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 shadow-2xs"
                >
                  <BookmarkPlus className="w-3.5 h-3.5" />
                  行きたい場所に保存
                </button>

                <button
                  type="button"
                  onClick={() =>
                    onCreateEventFromPlace({
                      id: 'preview',
                      calendarId: activeCalendarId,
                      name: previewPlace.name,
                      category: previewPlace.category,
                      lat: previewPlace.lat,
                      lng: previewPlace.lng,
                      address: previewPlace.address,
                      isVisited: false,
                      createdBy: '自分',
                    })
                  }
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition flex items-center gap-1"
                >
                  <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                  予定作成
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Places List Side Panel */}
        <div className="w-full lg:w-5/12 h-full flex flex-col bg-white border-t lg:border-t-0 lg:border-l border-slate-200 overflow-hidden">
          <div className="p-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
            <div className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              行きたい場所リスト ({filteredPlaces.length}件)
            </div>
            <span className="text-[11px] text-slate-400">カードクリックで詳細確認</span>
          </div>

          <div className="flex-1 overflow-y-auto p-3.5 space-y-3">
            {filteredPlaces.length === 0 ? (
              <div className="py-12 text-center text-slate-400">
                <MapPin className="w-10 h-10 mx-auto mb-2 text-slate-300 stroke-1" />
                <p className="text-sm font-medium">登録された場所がありません</p>
                <p className="text-xs mt-1">
                  上の検索窓でお店の名前を入力するか、地図をクリックしてピン留めしましょう！
                </p>
              </div>
            ) : (
              filteredPlaces.map((place) => {
                const config = CATEGORY_CONFIG[place.category] || CATEGORY_CONFIG.other;
                const isSelected = selectedPlace?.id === place.id;

                return (
                  <div
                    key={place.id}
                    onClick={() => jumpToPlace(place)}
                    className={`rounded-2xl border transition cursor-pointer relative overflow-hidden ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-50/40 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white hover:shadow-xs'
                    }`}
                  >
                    {place.imageUrl && (
                      <div className="h-28 w-full overflow-hidden relative bg-slate-100">
                        <img
                          src={place.imageUrl}
                          alt={place.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                        <span
                          className="absolute top-2 left-2 text-[10px] font-bold px-2 py-0.5 rounded-full shadow-2xs"
                          style={{ backgroundColor: config.bg, color: config.color }}
                        >
                          {config.emoji} {config.label}
                        </span>
                      </div>
                    )}

                    <div className="p-3.5">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          {!place.imageUrl && (
                            <span className="text-lg p-1.5 rounded-lg bg-slate-100">{config.emoji}</span>
                          )}
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-bold text-slate-900">{place.name}</h4>
                              {place.isVisited && (
                                <span className="px-1.5 py-0.5 rounded-sm bg-slate-100 text-slate-500 text-[10px] font-medium">
                                  訪問済
                                </span>
                              )}
                            </div>
                            {!place.imageUrl && (
                              <span
                                className="inline-block text-[10px] font-medium px-2 py-0.5 rounded-full mt-0.5"
                                style={{ backgroundColor: config.bg, color: config.color }}
                              >
                                {config.label}
                              </span>
                            )}
                          </div>
                        </div>

                      {/* Visited toggle */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onUpdatePlace({ ...place, isVisited: !place.isVisited });
                        }}
                        className={`text-xs px-2 py-1 rounded-lg border font-medium transition flex items-center gap-1 ${
                          place.isVisited
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {place.isVisited ? '訪問済' : '未訪'}
                      </button>
                    </div>

                    <p className="text-xs text-slate-500 mt-2 line-clamp-1">{place.address}</p>

                    {place.notes && (
                      <p className="text-xs text-slate-700 mt-1.5 bg-slate-50 p-2 rounded-lg border border-slate-100">
                        {place.notes}
                      </p>
                    )}

                    {/* Bottom action row with Weather & Disaster Check Button */}
                    <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2.5 pt-2 border-t border-slate-100">
                      <div className="flex items-center gap-2">
                        {place.rating && (
                          <span className="flex items-center gap-0.5 text-amber-500 font-medium">
                            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                            {place.rating}
                          </span>
                        )}
                        {place.budget && <span>予算: {place.budget}</span>}
                      </div>

                      <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                        {/* Weather & Disaster Check Button */}
                        <button
                          type="button"
                          onClick={() => fetchWeatherAndDisaster(place.name, place.lat, place.lng)}
                          className="px-2 py-1 bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 rounded-md font-semibold flex items-center gap-1 transition"
                          title="この地域の天気・警報・災害リスクを確認"
                        >
                          <CloudSun className="w-3 h-3 text-sky-600" />
                          天気・防災
                        </button>

                        {/* Create Calendar Event Button */}
                        <button
                          type="button"
                          onClick={() => onCreateEventFromPlace(place)}
                          className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-md font-medium flex items-center gap-1 transition"
                          title="この場所で予定を立てる"
                        >
                          <Calendar className="w-3 h-3" />
                          予定作成
                        </button>

                        {/* Google Maps link */}
                        <a
                          href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
                            place.address || `${place.lat},${place.lng}`
                          )}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1 hover:text-blue-600 transition"
                          title="Googleマップで経路確認"
                        >
                          <Navigation className="w-3.5 h-3.5" />
                        </a>

                        {/* Delete button */}
                        <button
                          type="button"
                          onClick={() => onDeletePlace(place.id)}
                          className="p-1 hover:text-red-600 transition"
                          title="ピンを削除"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
              })
            )}
          </div>
        </div>
      </div>

      {/* Weather & Disaster Safety Modal */}
      {weatherPlace && (
        <div className="fixed inset-0 z-[4500] bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150 overflow-hidden">
            <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center font-bold">
                  <CloudSun className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                    {weatherPlace.name}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    現地の天気予報 &amp; 気象警報・防災情報
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setWeatherPlace(null)}
                className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center text-xs"
              >
                ✕
              </button>
            </div>

            {isLoadingWeather ? (
              <div className="py-12 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-3">
                <div className="w-6 h-6 border-2 border-sky-600 border-t-transparent rounded-full animate-spin" />
                気象庁・最新気象データを取得中...
              </div>
            ) : weatherError ? (
              <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
                {weatherError}
              </div>
            ) : weatherData ? (
              <div className="space-y-4">
                {/* Disaster Safety Alert Banner */}
                <div
                  className={`p-3.5 rounded-xl border flex items-start gap-3 ${
                    weatherData.disaster.overallStatus === 'safe'
                      ? 'bg-emerald-50/80 border-emerald-200 text-emerald-900'
                      : weatherData.disaster.overallStatus === 'warning'
                      ? 'bg-rose-50/90 border-rose-300 text-rose-950'
                      : 'bg-amber-50/90 border-amber-300 text-amber-950'
                  }`}
                >
                  <div className="mt-0.5 shrink-0">
                    {weatherData.disaster.overallStatus === 'safe' ? (
                      <ShieldCheck className="w-5 h-5 text-emerald-600" />
                    ) : (
                      <AlertTriangle
                        className={`w-5 h-5 ${
                          weatherData.disaster.overallStatus === 'warning'
                            ? 'text-rose-600'
                            : 'text-amber-600'
                        }`}
                      />
                    )}
                  </div>
                  <div>
                    <div className="text-xs font-bold flex items-center gap-2">
                      <span>防災・警報ステータス:</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                          weatherData.disaster.overallStatus === 'safe'
                            ? 'bg-emerald-200/80 text-emerald-800'
                            : weatherData.disaster.overallStatus === 'warning'
                            ? 'bg-rose-200 text-rose-800'
                            : 'bg-amber-200 text-amber-900'
                        }`}
                      >
                        {weatherData.disaster.overallStatus === 'safe'
                          ? '安全・警報なし'
                          : weatherData.disaster.overallStatus === 'warning'
                          ? '気象警報・警戒'
                          : '注意報レベル'}
                      </span>
                    </div>
                    <p className="text-xs mt-1 leading-relaxed">
                      {weatherData.disaster.summaryMessage}
                    </p>

                    {/* Specific Alerts if any */}
                    {weatherData.disaster.alerts.length > 0 && (
                      <div className="mt-2 space-y-1.5 pt-2 border-t border-black/10">
                        {weatherData.disaster.alerts.map((alert, aIdx) => (
                          <div key={aIdx} className="text-[11px] font-medium">
                            ⚠️ <strong>{alert.title}</strong>: {alert.desc}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Current Weather Card */}
                <div className="p-3.5 bg-gradient-to-br from-sky-50 to-blue-50/60 rounded-xl border border-sky-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-4xl">{weatherData.current.emoji}</span>
                    <div>
                      <div className="text-lg font-black text-slate-900">
                        {weatherData.current.temp}°C
                        <span className="text-xs font-normal text-slate-500 ml-1.5">
                          (体感 {weatherData.current.apparentTemp}°C)
                        </span>
                      </div>
                      <div className="text-xs font-bold text-sky-900">
                        {weatherData.current.weatherLabel}
                      </div>
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-600 space-y-1 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Droplets className="w-3.5 h-3.5 text-sky-500" />
                      <span>湿度: {weatherData.current.humidity}%</span>
                    </div>
                    <div className="flex items-center justify-end gap-1">
                      <Wind className="w-3.5 h-3.5 text-sky-500" />
                      <span>風速: {weatherData.current.windSpeed} m/s</span>
                    </div>
                  </div>
                </div>

                {/* 5-Day Forecast Grid */}
                <div>
                  <h4 className="text-xs font-bold text-slate-700 mb-2">今後の天気予報 (5日間)</h4>
                  <div className="grid grid-cols-5 gap-1.5 text-center">
                    {weatherData.forecast.map((f, fIdx) => (
                      <div
                        key={fIdx}
                        className="p-2 bg-slate-50 rounded-xl border border-slate-100 flex flex-col items-center"
                      >
                        <span className="text-[10px] text-slate-500 font-semibold">
                          {new Date(f.date).toLocaleDateString('ja-JP', {
                            weekday: 'short',
                            day: 'numeric',
                          })}
                        </span>
                        <span className="text-xl my-1">{f.emoji}</span>
                        <span className="text-[11px] font-bold text-slate-800">
                          {f.maxTemp}° / <span className="text-slate-400 font-normal">{f.minTemp}°</span>
                        </span>
                        <span className="text-[10px] text-blue-600 font-bold mt-0.5">
                          ☔ {f.rainProb}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setWeatherPlace(null)}
                    className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-semibold"
                  >
                    閉じる
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* Add New Place Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[4500] bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                  <MapPin className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-900">新しい場所をピン留め</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveModal} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  場所・店舗名 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={modalForm.name}
                  onChange={(e) => setModalForm({ ...modalForm, name: e.target.value })}
                  placeholder="例: ブルーボトルコーヒー、チームラボ、〇〇展望台"
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ジャンル</label>
                  <select
                    value={modalForm.category}
                    onChange={(e) =>
                      setModalForm({ ...modalForm, category: e.target.value as PlaceCategory })
                    }
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm bg-white"
                  >
                    {Object.entries(CATEGORY_CONFIG).map(([key, cfg]) => (
                      <option key={key} value={key}>
                        {cfg.emoji} {cfg.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">目安の予算</label>
                  <input
                    type="text"
                    value={modalForm.budget}
                    onChange={(e) => setModalForm({ ...modalForm, budget: e.target.value })}
                    placeholder="例: ¥2,000 /人"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">住所・場所</label>
                <input
                  type="text"
                  value={modalForm.address}
                  onChange={(e) => setModalForm({ ...modalForm, address: e.target.value })}
                  placeholder="住所または最寄り駅など"
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">行きたい理由・メモ</label>
                <textarea
                  rows={2}
                  value={modalForm.notes}
                  onChange={(e) => setModalForm({ ...modalForm, notes: e.target.value })}
                  placeholder="例: テラス席が人気！予約必須。プリンが美味しいらしい。"
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm resize-none"
                />
              </div>

              {/* Weather quick test button inside modal */}
              <div className="pt-1">
                <button
                  type="button"
                  onClick={() =>
                    fetchWeatherAndDisaster(
                      modalForm.name || 'この場所',
                      modalForm.lat,
                      modalForm.lng
                    )
                  }
                  className="w-full py-1.5 px-3 bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                >
                  <CloudSun className="w-3.5 h-3.5 text-sky-600" />
                  この場所の現在の天気・災害リスクをチェック
                </button>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl text-xs font-medium hover:bg-slate-50 transition"
                >
                  キャンセル
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs transition"
                >
                  地図にピン留めする
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
