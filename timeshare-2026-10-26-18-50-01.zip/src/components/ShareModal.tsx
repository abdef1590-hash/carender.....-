import React, { useState } from 'react';
import {
  Share2,
  Copy,
  Check,
  QrCode,
  Users,
  Plus,
  Shield,
  Sparkles,
  Link as LinkIcon,
  UserPlus,
} from 'lucide-react';
import { SharedCalendar, Member } from '../types';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeCalendar: SharedCalendar;
  calendars: SharedCalendar[];
  onJoinCalendarByCode: (code: string) => boolean;
  onCreateNewCalendar: (newCal: Omit<SharedCalendar, 'id'>) => void;
  onAddMemberToCalendar: (calendarId: string, member: Member) => void;
  initialTab?: 'share' | 'join' | 'create';
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  activeCalendar,
  onJoinCalendarByCode,
  onCreateNewCalendar,
  onAddMemberToCalendar,
  initialTab = 'share',
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [joinError, setJoinError] = useState('');
  const [joinSuccess, setJoinSuccess] = useState('');

  // New Calendar Tab
  const [activeTab, setActiveTab] = useState<'share' | 'join' | 'create'>(initialTab);

  React.useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  const [newCalName, setNewCalName] = useState('');
  const [newCalDesc, setNewCalDesc] = useState('');
  const [newCalEmoji, setNewCalEmoji] = useState('📅');
  const [newCalColor, setNewCalColor] = useState('#10B981');

  // Quick invite member
  const [inviteName, setInviteName] = useState('');
  const [inviteColor, setInviteColor] = useState('#F59E0B');

  if (!isOpen) return null;

  const shareUrl = `${window.location.origin}?calendar=${activeCalendar.inviteCode}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(activeCalendar.inviteCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    setJoinError('');
    setJoinSuccess('');

    const success = onJoinCalendarByCode(joinCodeInput.trim().toUpperCase());
    if (success) {
      setJoinSuccess(`「${joinCodeInput}」のカレンダーに参加しました！`);
      setJoinCodeInput('');
      setTimeout(() => {
        onClose();
      }, 1200);
    } else {
      setJoinError('招待コードが見つかりません。コードをお確かめください。');
    }
  };

  const handleCreateCalendar = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCalName.trim()) return;

    const randomCode = `TREE-${Math.floor(1000 + Math.random() * 9000)}`;

    onCreateNewCalendar({
      name: newCalName.trim(),
      description: newCalDesc.trim(),
      color: newCalColor,
      emoji: newCalEmoji,
      inviteCode: randomCode,
      members: activeCalendar.members,
    });

    onClose();
  };

  const handleQuickAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName.trim()) return;

    const newMember: Member = {
      id: `m-${Date.now()}`,
      name: inviteName.trim(),
      avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(inviteName)}`,
      color: inviteColor,
      role: 'member',
    };

    onAddMemberToCalendar(activeCalendar.id, newMember);
    setInviteName('');
  };

  return (
    <div className="fixed inset-0 z-[2000] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto pb-safe">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl max-w-md w-full max-h-[90vh] flex flex-col shadow-2xl animate-in fade-in zoom-in-95 duration-150 overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <span className="text-xl">{activeCalendar.emoji}</span>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">{activeCalendar.name} の共有</h3>
              <p className="text-[11px] text-slate-500">家族やパートナー、同僚と予定を同期</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-200/70 hover:bg-slate-200 text-slate-600 flex items-center justify-center text-xs transition"
          >
            ✕
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-100 bg-white px-5 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('share')}
            className={`py-2.5 px-3 border-b-2 transition ${
              activeTab === 'share'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            招待・メンバー
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('join')}
            className={`py-2.5 px-3 border-b-2 transition ${
              activeTab === 'join'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            コードで参加
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('create')}
            className={`py-2.5 px-3 border-b-2 transition ${
              activeTab === 'create'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            新規カレンダー作成
          </button>
        </div>

        {/* Tab 1: Share / Invite */}
        {activeTab === 'share' && (
          <div className="p-5 space-y-4">
            {/* Invite Code Card */}
            <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 text-center space-y-2">
              <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider">
                このカレンダーの招待コード
              </span>
              <div className="text-2xl font-black text-emerald-900 font-mono tracking-widest">
                {activeCalendar.inviteCode}
              </div>
              <p className="text-[11px] text-emerald-700">
                相手がアプリ内でこのコードを入力すると、自動的に共有されます
              </p>

              <div className="flex items-center justify-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 shadow-xs"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedCode ? 'コピー完了！' : 'コードをコピー'}
                </button>
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="px-3.5 py-1.5 bg-white hover:bg-slate-50 border border-emerald-300 text-emerald-800 rounded-lg text-xs font-medium transition flex items-center gap-1 shadow-xs"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <LinkIcon className="w-3.5 h-3.5" />}
                  {copiedLink ? 'リンクコピー済' : '招待リンクをコピー'}
                </button>
              </div>
            </div>

            {/* Members List */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-emerald-600" />
                  現在の参加メンバー ({activeCalendar.members.length}名)
                </span>
              </div>

              <div className="space-y-2 max-h-40 overflow-y-auto">
                {activeCalendar.members.map((member) => (
                  <div
                    key={member.id}
                    className="flex items-center justify-between p-2 rounded-xl border border-slate-100 bg-slate-50"
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={member.avatarUrl}
                        alt={member.name}
                        className="w-7 h-7 rounded-full object-cover"
                      />
                      <div>
                        <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                          {member.name}
                          {member.role === 'owner' && (
                            <span className="px-1.5 py-0.2 bg-emerald-100 text-emerald-700 text-[9px] font-semibold rounded-sm">
                              作成者
                            </span>
                          )}
                        </div>
                        {member.email && (
                          <div className="text-[10px] text-slate-400">{member.email}</div>
                        )}
                      </div>
                    </div>
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: member.color }}
                      title="担当カラー"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Add simulated member */}
            <form onSubmit={handleQuickAddMember} className="pt-2 border-t border-slate-100 space-y-2">
              <span className="text-[11px] font-semibold text-slate-600 flex items-center gap-1">
                <UserPlus className="w-3.5 h-3.5 text-emerald-600" />
                シミュレーション: メンバーを即座に追加
              </span>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inviteName}
                  onChange={(e) => setInviteName(e.target.value)}
                  placeholder="メンバー名 (例: お母さん、田中店長)"
                  className="flex-1 px-3 py-1.5 border border-slate-200 rounded-lg text-xs"
                />
                <input
                  type="color"
                  value={inviteColor}
                  onChange={(e) => setInviteColor(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer p-0.5 border border-slate-200"
                  title="表示カラー"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-medium transition"
                >
                  追加
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Tab 2: Join by code */}
        {activeTab === 'join' && (
          <div className="p-5 space-y-4">
            <p className="text-xs text-slate-600 leading-relaxed">
              知人やパートナーから共有された「招待コード」を入力してください。
            </p>

            <form onSubmit={handleJoin} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  6桁の招待コード
                </label>
                <input
                  type="text"
                  required
                  value={joinCodeInput}
                  onChange={(e) => setJoinCodeInput(e.target.value.toUpperCase())}
                  placeholder="例: TREE-7749"
                  className="w-full text-center tracking-widest font-mono text-base font-bold px-3 py-2 border-2 border-slate-200 focus:border-emerald-600 rounded-xl"
                />
              </div>

              {joinError && (
                <p className="text-xs text-rose-600 bg-rose-50 p-2 rounded-lg border border-rose-200">
                  {joinError}
                </p>
              )}
              {joinSuccess && (
                <p className="text-xs text-emerald-700 bg-emerald-50 p-2 rounded-lg border border-emerald-200 font-bold">
                  {joinSuccess}
                </p>
              )}

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition"
              >
                共有カレンダーに参加する
              </button>
            </form>
          </div>
        )}

        {/* Tab 3: Create New Shared Calendar */}
        {activeTab === 'create' && (
          <div className="p-5 space-y-4">
            <form onSubmit={handleCreateCalendar} className="space-y-3.5">
              <div className="flex gap-2">
                <div className="w-16">
                  <label className="block text-xs font-bold text-slate-700 mb-1">アイコン</label>
                  <input
                    type="text"
                    value={newCalEmoji}
                    onChange={(e) => setNewCalEmoji(e.target.value)}
                    maxLength={2}
                    className="w-full text-center text-lg py-1.5 border border-slate-200 rounded-xl"
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    カレンダー名 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={newCalName}
                    onChange={(e) => setNewCalName(e.target.value)}
                    placeholder="例: サークル連絡、旅行プロジェクト"
                    className="w-full px-3 py-1.5 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">説明 (任意)</label>
                <input
                  type="text"
                  value={newCalDesc}
                  onChange={(e) => setNewCalDesc(e.target.value)}
                  placeholder="メンバー向けの説明"
                  className="w-full px-3 py-1.5 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">テーマカラー</label>
                <div className="flex gap-2 items-center">
                  {['#10B981', '#3B82F6', '#EC4899', '#F59E0B', '#8B5CF6', '#EF4444'].map((col) => (
                    <button
                      key={col}
                      type="button"
                      onClick={() => setNewCalColor(col)}
                      className={`w-7 h-7 rounded-full transition ${
                        newCalColor === col ? 'ring-2 ring-offset-2 ring-slate-800 scale-110' : ''
                      }`}
                      style={{ backgroundColor: col }}
                    />
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition"
                >
                  新しい共有カレンダーを作成
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
