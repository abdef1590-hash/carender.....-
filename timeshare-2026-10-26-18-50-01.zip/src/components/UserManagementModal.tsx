import React, { useState } from 'react';
import {
  UserPlus,
  Users,
  Lock,
  Unlock,
  KeyRound,
  Eye,
  EyeOff,
  Check,
  Trash2,
  ShieldCheck,
  Sparkles,
  AlertCircle,
  UserCheck,
} from 'lucide-react';
import { Member, SharedCalendar } from '../types';

interface UserManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  members: Member[];
  currentMember: Member;
  calendars: SharedCalendar[];
  activeCalendarId: string;
  onAddUser: (
    newMember: Member,
    addToAllCalendars: boolean,
    createShiftProfile: boolean
  ) => void;
  onUpdateUser: (updatedMember: Member) => void;
  onDeleteUser: (memberId: string) => void;
  onSelectUser: (member: Member) => void;
}

const PRESET_COLORS = [
  '#10B981', // Emerald
  '#EC4899', // Pink
  '#3B82F6', // Blue
  '#F59E0B', // Amber
  '#8B5CF6', // Purple
  '#06B6D4', // Cyan
  '#F43F5E', // Rose
  '#6366F1', // Indigo
];

const PRESET_AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=150&q=80',
];

export const UserManagementModal: React.FC<UserManagementModalProps> = ({
  isOpen,
  onClose,
  members,
  currentMember,
  calendars,
  onAddUser,
  onUpdateUser,
  onDeleteUser,
  onSelectUser,
}) => {
  const [activeTab, setActiveTab] = useState<'add' | 'list'>('add');

  // New User Form State
  const [name, setName] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [color, setColor] = useState('#3B82F6');
  const [avatarUrl, setAvatarUrl] = useState(PRESET_AVATARS[2]);
  const [role, setRole] = useState<'owner' | 'member'>('member');
  const [enablePassword, setEnablePassword] = useState(true);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [addToAllCalendars, setAddToAllCalendars] = useState(true);
  const [createShiftProfile, setCreateShiftProfile] = useState(true);
  const [formError, setFormError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Edit Password / Profile inline state in List Tab
  const [editingMemberId, setEditingMemberId] = useState<string | null>(null);
  const [currentPassVerify, setCurrentPassVerify] = useState('');
  const [editNewPassword, setEditNewPassword] = useState('');
  const [editEnablePassword, setEditEnablePassword] = useState(true);
  const [editName, setEditName] = useState('');
  const [editColor, setEditColor] = useState('#10B981');
  const [editError, setEditError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const trimmedName = name.trim();
    if (!trimmedName) {
      setFormError('ユーザー名を入力してください。');
      return;
    }

    if (enablePassword) {
      if (!password || password.length < 4) {
        setFormError('パスワードは4文字以上で設定してください。');
        return;
      }
      if (password !== confirmPassword) {
        setFormError('確認用パスワードが一致しません。');
        return;
      }
    }

    const newMember: Member = {
      id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: trimmedName,
      avatarUrl:
        avatarUrl.trim() ||
        `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(trimmedName)}`,
      color,
      role,
      jobTitle: jobTitle.trim() || undefined,
      isPasswordProtected: enablePassword,
      password: enablePassword ? password : undefined,
    };

    onAddUser(newMember, addToAllCalendars, createShiftProfile);

    // Reset form
    setName('');
    setJobTitle('');
    setPassword('');
    setConfirmPassword('');
    setSuccessMsg(
      `ユーザー「${newMember.name}」${
        enablePassword ? '（🔒パスワード保護付き）' : ''
      }を追加し、全端末へリアルタイム同期しました！`
    );
    setTimeout(() => {
      setSuccessMsg(null);
      setActiveTab('list');
    }, 1800);
  };

  const startEditingMember = (m: Member) => {
    setEditingMemberId(m.id);
    setCurrentPassVerify('');
    setEditNewPassword(m.password || '');
    setEditEnablePassword(Boolean(m.isPasswordProtected));
    setEditName(m.name);
    setEditColor(m.color);
    setEditError(null);
  };

  const handleSaveMemberEdit = (m: Member) => {
    setEditError(null);

    // If member already had a password, require current password to modify
    if (m.isPasswordProtected && m.password && currentPassVerify !== m.password) {
      setEditError('現在のパスワードが正しくありません。');
      return;
    }

    if (editEnablePassword && (!editNewPassword || editNewPassword.length < 4)) {
      setEditError('新しいパスワードは4文字以上で入力してください。');
      return;
    }

    const updated: Member = {
      ...m,
      name: editName.trim() || m.name,
      color: editColor,
      isPasswordProtected: editEnablePassword,
      password: editEnablePassword ? editNewPassword : undefined,
    };

    onUpdateUser(updated);
    setEditingMemberId(null);
    setSuccessMsg(`「${updated.name}」のユーザー設定・パスワードを更新しました！`);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-[2100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto pb-safe">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl max-w-xl w-full max-h-[92vh] flex flex-col shadow-2xl animate-in fade-in zoom-in-95 duration-150 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-slate-800 to-slate-900 text-white shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center">
              <UserPlus className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="font-bold text-base flex items-center gap-2">
                ユーザー追加・パスワード設定
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  複数端末リアルタイム同期
                </span>
              </h3>
              <p className="text-xs text-slate-300">
                2ユーザー運用やシフト表ごとの担当者追加・パスワード保護を管理
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-sm transition cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 bg-white px-6 text-xs font-bold shrink-0">
          <button
            type="button"
            onClick={() => {
              setActiveTab('add');
              setFormError(null);
            }}
            className={`py-3 px-4 border-b-2 flex items-center gap-1.5 transition cursor-pointer ${
              activeTab === 'add'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            新規ユーザー追加 (パスワード設定)
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('list');
              setFormError(null);
            }}
            className={`py-3 px-4 border-b-2 flex items-center gap-1.5 transition cursor-pointer ${
              activeTab === 'list'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            登録ユーザー一覧・パスワード管理
            <span className="bg-slate-100 text-slate-700 text-[10px] px-1.5 py-0.2 rounded-full">
              {members.length}名
            </span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {successMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-bold flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* TAB 1: ADD NEW USER */}
          {activeTab === 'add' && (
            <form onSubmit={handleCreateUser} className="space-y-4">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 font-semibold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ユーザー名 / 表示名 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="例: あおい / たくま / 佐藤"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    職場・シフト区分メモ (任意)
                  </label>
                  <input
                    type="text"
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                    placeholder="例: 病院3交代 / カフェ早遅"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Color & Role Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    担当テーマカラー
                  </label>
                  <div className="flex items-center gap-2 flex-wrap">
                    {PRESET_COLORS.map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setColor(c)}
                        className={`w-6 h-6 rounded-full transition cursor-pointer ${
                          color === c ? 'ring-2 ring-offset-2 ring-slate-800 scale-110' : ''
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                    <input
                      type="color"
                      value={color}
                      onChange={(e) => setColor(e.target.value)}
                      className="w-7 h-7 rounded-lg cursor-pointer p-0.5 border border-slate-200 bg-white"
                      title="自由な色を選択"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">権限ロール</label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setRole('member')}
                      className={`flex-1 py-1.5 px-3 rounded-xl border text-xs font-bold transition cursor-pointer ${
                        role === 'member'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                          : 'bg-white border-slate-200 text-slate-600'
                      }`}
                    >
                      メンバー
                    </button>
                    <button
                      type="button"
                      onClick={() => setRole('owner')}
                      className={`flex-1 py-1.5 px-3 rounded-xl border text-xs font-bold transition cursor-pointer ${
                        role === 'owner'
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                          : 'bg-white border-slate-200 text-slate-600'
                      }`}
                    >
                      管理者 (オーナー)
                    </button>
                  </div>
                </div>
              </div>

              {/* Avatar Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  プロフィールアイコン選択
                </label>
                <div className="flex items-center gap-2.5 flex-wrap">
                  {PRESET_AVATARS.map((url, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setAvatarUrl(url)}
                      className={`w-10 h-10 rounded-full overflow-hidden border-2 transition cursor-pointer ${
                        avatarUrl === url
                          ? 'border-emerald-600 ring-2 ring-emerald-500/30 scale-105'
                          : 'border-slate-200 opacity-75 hover:opacity-100'
                      }`}
                    >
                      <img src={url} alt={`Avatar ${idx + 1}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Password Protection Section */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                        enablePassword
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-slate-200 text-slate-500'
                      }`}
                    >
                      {enablePassword ? (
                        <Lock className="w-4 h-4" />
                      ) : (
                        <Unlock className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">
                        パスワード保護を設定する
                      </div>
                      <div className="text-[11px] text-slate-500">
                        別端末やユーザー切替時にパスワード（またはPIN）による本人確認を行います
                      </div>
                    </div>
                  </div>

                  <label className="inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={enablePassword}
                      onChange={(e) => setEnablePassword(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-10 h-5.5 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4.5 after:w-4.5 after:transition-all relative peer-checked:bg-emerald-600" />
                  </label>
                </div>

                {enablePassword && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200/80">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        パスワード (4文字以上) <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          type={showPassword ? 'text' : 'password'}
                          required={enablePassword}
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="パスワードまたは4桁PIN"
                          className="w-full pl-3 pr-8 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-2 top-1.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                        >
                          {showPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        パスワード（確認用） <span className="text-red-500">*</span>
                      </label>
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required={enablePassword}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="もう一度入力"
                        className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Options for Shift Profile & Calendar Assignment */}
              <div className="p-3.5 rounded-xl bg-emerald-50/60 border border-emerald-200 space-y-2 text-xs">
                <label className="flex items-center gap-2 cursor-pointer font-semibold text-emerald-950">
                  <input
                    type="checkbox"
                    checked={createShiftProfile}
                    onChange={(e) => setCreateShiftProfile(e.target.checked)}
                    className="rounded-sm text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                  />
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>
                    このユーザー専用の「シフト表ルール設定」も同時に自動作成する
                  </span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-700">
                  <input
                    type="checkbox"
                    checked={addToAllCalendars}
                    onChange={(e) => setAddToAllCalendars(e.target.checked)}
                    className="rounded-sm text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                  />
                  <span>すべての共有カレンダー（{calendars.length}件）にメンバーとして追加する</span>
                </label>
              </div>

              <div className="pt-1 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl text-xs font-medium hover:bg-slate-50 transition cursor-pointer"
                >
                  閉じる
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer"
                >
                  <UserPlus className="w-4 h-4" />
                  ユーザーを追加して同期する
                </button>
              </div>
            </form>
          )}

          {/* TAB 2: EXISTING USERS & PASSWORD SETTINGS */}
          {activeTab === 'list' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500">
                既存のユーザー（たくま・あおい等）にもパスワードを設定・変更したり、操作するユーザーを切り替えられます。
              </p>

              <div className="space-y-2.5">
                {members.map((m) => {
                  const isCurrent = m.id === currentMember.id;
                  const isEditing = editingMemberId === m.id;

                  return (
                    <div
                      key={m.id}
                      className={`p-3.5 rounded-2xl border transition ${
                        isCurrent
                          ? 'bg-emerald-50/40 border-emerald-300'
                          : 'bg-white border-slate-200'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-3">
                          <div className="relative">
                            <img
                              src={m.avatarUrl}
                              alt={m.name}
                              className="w-10 h-10 rounded-full object-cover border-2"
                              style={{ borderColor: m.color }}
                            />
                            <span
                              className="w-3 h-3 rounded-full absolute -bottom-0.5 -right-0.5 border-2 border-white"
                              style={{ backgroundColor: m.color }}
                            />
                          </div>

                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-sm font-bold text-slate-900">{m.name}</span>
                              {isCurrent && (
                                <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded-full">
                                  現在操作中
                                </span>
                              )}
                              {m.isPasswordProtected ? (
                                <span className="px-2 py-0.5 bg-amber-100 text-amber-800 border border-amber-200 text-[10px] font-bold rounded-full flex items-center gap-1">
                                  <Lock className="w-2.5 h-2.5" />
                                  パスワード保護中
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 bg-slate-100 text-slate-500 text-[10px] font-medium rounded-full flex items-center gap-1">
                                  <Unlock className="w-2.5 h-2.5" />
                                  パスワード未設定
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-500 mt-0.5">
                              {m.jobTitle || (m.role === 'owner' ? '管理者 (オーナー)' : '共有メンバー')}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {!isCurrent && (
                            <button
                              type="button"
                              onClick={() => onSelectUser(m)}
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer shadow-2xs"
                            >
                              <UserCheck className="w-3.5 h-3.5" />
                              このユーザーに切替
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() =>
                              isEditing ? setEditingMemberId(null) : startEditingMember(m)
                            }
                            className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition flex items-center gap-1 cursor-pointer"
                          >
                            <KeyRound className="w-3.5 h-3.5 text-slate-600" />
                            <span>{isEditing ? '閉じる' : 'パスワード・設定'}</span>
                          </button>

                          {members.length > 1 && (
                            <button
                              type="button"
                              onClick={() => onDeleteUser(m.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition cursor-pointer"
                              title="ユーザーを削除"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Inline Password & Profile Editor */}
                      {isEditing && (
                        <div className="mt-3 pt-3 border-t border-slate-200 space-y-3 text-xs bg-slate-50 p-3 rounded-xl">
                          {editError && (
                            <div className="p-2 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg font-semibold">
                              {editError}
                            </div>
                          )}

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                            <div>
                              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                                ユーザー名
                              </label>
                              <input
                                type="text"
                                value={editName}
                                onChange={(e) => setEditName(e.target.value)}
                                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                                担当カラー
                              </label>
                              <div className="flex items-center gap-1.5">
                                {PRESET_COLORS.slice(0, 6).map((c) => (
                                  <button
                                    key={c}
                                    type="button"
                                    onClick={() => setEditColor(c)}
                                    className={`w-5 h-5 rounded-full cursor-pointer ${
                                      editColor === c ? 'ring-2 ring-offset-1 ring-slate-800' : ''
                                    }`}
                                    style={{ backgroundColor: c }}
                                  />
                                ))}
                              </div>
                            </div>
                          </div>

                          {m.isPasswordProtected && m.password && (
                            <div>
                              <label className="block text-[11px] font-bold text-amber-800 mb-1">
                                現在のパスワード（変更・解除するには入力してください）
                              </label>
                              <input
                                type="password"
                                value={currentPassVerify}
                                onChange={(e) => setCurrentPassVerify(e.target.value)}
                                placeholder="現在のパスワードを入力"
                                className="w-full px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg font-mono"
                              />
                            </div>
                          )}

                          <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                            <label className="inline-flex items-center gap-1.5 font-bold text-slate-800 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={editEnablePassword}
                                onChange={(e) => setEditEnablePassword(e.target.checked)}
                                className="rounded-sm text-emerald-600 w-4 h-4"
                              />
                              <span>パスワード保護を有効にする</span>
                            </label>

                            {editEnablePassword && (
                              <input
                                type="password"
                                value={editNewPassword}
                                onChange={(e) => setEditNewPassword(e.target.value)}
                                placeholder="新しいパスワード (4文字以上)"
                                className="flex-1 min-w-44 px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg font-mono"
                              />
                            )}
                          </div>

                          <div className="flex justify-end gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => setEditingMemberId(null)}
                              className="px-3 py-1.5 text-slate-500 hover:text-slate-700 cursor-pointer"
                            >
                              キャンセル
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSaveMemberEdit(m)}
                              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold cursor-pointer flex items-center gap-1"
                            >
                              <ShieldCheck className="w-3.5 h-3.5" />
                              設定を保存
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Password Verification Modal when switching to a password-protected user
interface PasswordUnlockModalProps {
  targetMember: Member | null;
  onCancel: () => void;
  onSuccess: (member: Member) => void;
}

export const PasswordUnlockModal: React.FC<PasswordUnlockModalProps> = ({
  targetMember,
  onCancel,
  onSuccess,
}) => {
  const [inputPassword, setInputPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!targetMember) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputPassword === targetMember.password) {
      setInputPassword('');
      setError(null);
      onSuccess(targetMember);
    } else {
      setError('パスワードが一致しません。もう一度お確かめください。');
    }
  };

  return (
    <div className="fixed inset-0 z-[2500] bg-black/65 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150 space-y-4">
        <div className="flex items-center gap-3">
          <img
            src={targetMember.avatarUrl}
            alt={targetMember.name}
            className="w-11 h-11 rounded-full object-cover border-2"
            style={{ borderColor: targetMember.color }}
          />
          <div>
            <div className="text-xs font-bold text-amber-700 flex items-center gap-1">
              <Lock className="w-3.5 h-3.5" />
              パスワード保護されたユーザー
            </div>
            <h4 className="font-bold text-slate-900 text-sm">
              「{targetMember.name}」へ切り替え
            </h4>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              パスワードを入力してください:
            </label>
            <input
              type="password"
              autoFocus
              required
              value={inputPassword}
              onChange={(e) => {
                setInputPassword(e.target.value);
                setError(null);
              }}
              placeholder="パスワードを入力"
              className="w-full px-3 py-2 border-2 border-slate-200 focus:border-emerald-600 rounded-xl text-sm font-mono focus:outline-hidden"
            />
          </div>

          {error && (
            <p className="text-xs text-rose-600 bg-rose-50 p-2 rounded-lg border border-rose-200 font-semibold">
              {error}
            </p>
          )}

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={onCancel}
              className="px-3.5 py-2 border border-slate-200 text-slate-600 rounded-xl text-xs font-medium hover:bg-slate-50 cursor-pointer"
            >
              キャンセル
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Unlock className="w-3.5 h-3.5" />
              ロック解除して切り替え
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
