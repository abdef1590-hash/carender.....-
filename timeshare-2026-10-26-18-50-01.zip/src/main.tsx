import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import 'leaflet/dist/leaflet.css';
import './index.css';

// Guard against unhandled network rejections (such as WebKit "Load failed" / CORS blocks)
window.addEventListener('unhandledrejection', (event) => {
  const msg = event.reason?.message || '';
  if (msg === 'Load failed' || msg === 'Failed to fetch' || event.reason?.name === 'TypeError') {
    console.warn('Network request failed or resource blocked gracefully handled:', event.reason);
    event.preventDefault();
  }
});

createRoot(document.getElementById('root')!).render(<App />);
